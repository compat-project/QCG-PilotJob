The QCG Pilot Manager

Author: Piotr Kopta <pkopta@man.poznan.pl>
Copyright (C) 2017-2018 Poznan Supercomputing and Networking Center

The QCG Pilot Manager documentation is available at:
